function signUp() {
    window.location.href = 'signup.php';
}
